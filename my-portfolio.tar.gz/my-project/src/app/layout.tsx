import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Providers } from "./providers";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "John Doe - Full-Stack Developer Portfolio",
  description: "Personal portfolio of John Doe, a full-stack developer and UI/UX designer specializing in modern web technologies.",
  keywords: ["portfolio", "full-stack developer", "web developer", "UI/UX designer", "React", "Next.js", "TypeScript"],
  authors: [{ name: "John Doe" }],
  openGraph: {
    title: "John Doe - Portfolio",
    description: "Full-stack developer and UI/UX designer portfolio",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "John Doe - Portfolio",
    description: "Full-stack developer and UI/UX designer portfolio",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <Providers>
          {children}
          <Toaster />
        </Providers>
      </body>
    </html>
  );
}
